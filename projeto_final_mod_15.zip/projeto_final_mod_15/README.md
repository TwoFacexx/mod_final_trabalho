Projeto: Gestão de Clientes de Ginásio

Este projeto é um sistema simples de gestão de clientes de ginásio, utilizando Python e SQLite para armazenar e manipular dados relacionados a clientes, incluindo o cálculo do IMC e a recomendação de planos de treino.

Estrutura do Projeto

📦 gym-management
├── 📂 src
│   ├── 📂 create
│   │   ├── create.py
│   │   ├── insert.py
│   ├── 📂 update
│   │   ├── update.py
│   ├── 📂 delete
│   │   ├── delete.py
│   │   ├── drop.py
│   ├── 📂 read
│   │   ├── select.py
│   │   ├── grau.py
│   │   ├── plano.py
│   ├── main.py
├── README.md
└── gym.db

Como Utilizar

1. Instalar Dependências

Este projeto não necessita de bibliotecas externas, apenas Python instalado no sistema.

2. Criar o Banco de Dados

O ficheiro create.py cria automaticamente a tabela clientes no banco de dados SQLite.

Executa o seguinte comando para criar a tabela:

python src/create/create.py

