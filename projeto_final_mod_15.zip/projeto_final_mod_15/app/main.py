# Importação das bibliotecas necessárias
import sqlite3  # Biblioteca para manipulação de bancos de dados SQLite
import os  # Biblioteca para interagir com o sistema operacional

# Importação de funções de módulos personalizados que realizam operações no banco de dados
from src.create.insert import inserir_cliente  # Função para inserir um novo cliente
from src.update.update import atualizar_cliente  # Função para atualizar dados de um cliente existente
from src.delete.delete import delete_cliente  # Função para deletar um cliente do banco de dados
from src.delete.drop import apagar_tabela  # Função para apagar uma tabela inteira do banco de dados
from src.read.select import select_dados  # Função para recuperar e exibir todos os dados do banco
from src.read.grau import sel_dados  # Função para exibir a categoria do IMC dos clientes
from src.read.plano import plan  # Função para obter um plano de treino ideal para o cliente

# Função para limpar o console do terminal
def clear_console():
    if os.name == 'nt':  # Verifica se o sistema operacional é Windows
        os.system('cls')  # Comando para limpar o terminal no Windows
    else: 
        os.system('clear')  # Comando para limpar o terminal no Linux e macOS

# Função principal que exibe o menu e gerencia a interação com o usuário
def menu():
    while True:  # Loop infinito até que o usuário escolha sair
        
        # Abre uma conexão com o banco de dados SQLite
        conexao = sqlite3.connect('../gym.db')
        
        # Exibição do menu de opções
        print("=== Menu ===")
        print("1. Registar Clientes")
        print("2. Atualizar Cliente")
        print("3. Apagar Cliente")
        print("4. Apagar Tabela")
        print("5. Recolher todos os dados")
        print("6. Mostrar categoria do imc")
        print("7. Buscar tipo de plano de treino ideal para aluno")
        print("8. Sair")
        
        # Solicita que o usuário escolha uma opção
        opcao = input("Escolha uma opcao: ")

        # Verifica a opção escolhida e chama a função correspondente
        if opcao == "1":
            clear_console()  # Limpa o terminal
            inserir_cliente(conexao)  # Chama a função para registrar um novo cliente
        
        elif opcao == "2":
            clear_console()  # Limpa o terminal
            atualizar_cliente(conexao)  # Chama a função para atualizar um cliente
        
        elif opcao == "3":
            clear_console()  # Limpa o terminal
            delete_cliente(conexao)  # Chama a função para deletar um cliente
        
        elif opcao == "4":
            clear_console()  # Limpa o terminal
            apagar_tabela(conexao)  # Chama a função para apagar uma tabela inteira do banco
        
        elif opcao == "5":
            clear_console()  # Limpa o terminal
            select_dados(conexao)  # Chama a função para recuperar e exibir todos os dados do banco
        
        elif opcao == "6":
            clear_console()  # Limpa o terminal
            sel_dados(conexao)  # Chama a função para exibir a categoria do IMC dos clientes
        
        elif opcao == "7":
            clear_console()  # Limpa o terminal
            plan(conexao)  # Chama a função para buscar o plano de treino ideal para o aluno
        
        elif opcao == "8":
            conexao.close()  # Fecha a conexão com o banco de dados
            clear_console()  # Limpa o terminal
            break  # Encerra o loop e sai do programa
        
        else:
            print("Opção inválida!")  # Mensagem de erro caso o usuário insira uma opção inválida

# Chamada da função menu para iniciar o programa
menu()
