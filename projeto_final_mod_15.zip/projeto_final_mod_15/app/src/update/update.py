# Importação da biblioteca SQLite3 para manipulação do banco de dados
import sqlite3

# Função para atualizar os dados de um cliente na tabela 'clientes'
def atualizar_cliente(conexao):
    # Criação do cursor para executar comandos SQL
    cursor = conexao.cursor()

    # Solicita ao usuário qual coluna deseja atualizar (nome, idade, peso ou altura)
    coluna = input("O que quer atualizar (nome, idade, peso, altura): ")
    
    # Solicita o ID do cliente que terá seus dados modificados
    cliente_id = input("Qual é o ID do cliente que quer modificar: ")
    
    # Solicita o novo valor que será inserido na coluna escolhida
    novo_valor = input(f"Digite o novo valor para {coluna}: ")

    # Executa a consulta SQL para atualizar o dado específico do cliente
    cursor.execute(f'UPDATE clientes SET {coluna} = ? WHERE id = ?', (novo_valor, cliente_id))

    # Confirma as alterações no banco de dados
    conexao.commit()
    
    # Fecha a conexão com o banco de dados
    conexao.close()

    # Exibe uma mensagem confirmando a atualização bem-sucedida
    print(f"Cliente {cliente_id} atualizado com sucesso! {coluna} agora é {novo_valor}.")
