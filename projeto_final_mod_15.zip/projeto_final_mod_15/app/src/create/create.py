# Importação da biblioteca SQLite3 para manipulação do banco de dados
import sqlite3

# Função para criar a tabela 'clientes' no banco de dados, caso ainda não exista
def create_clientes_table():
    # Conecta ao banco de dados 'gym.db' (localizado em um diretório específico)
    conexao = sqlite3.connect('../../../gym.db')
    
    # Cria um cursor para interagir com o banco de dados
    cursor = conexao.cursor()
    
    # Comando SQL para criar a tabela 'clientes' caso ela ainda não exista, sendo que id é a chave primária e recebe autoincrement, ou seja, 
    # é dada automaticamente e não é necessário o utilizador colocar
    #todos os outros são TEXT NOT NULL, ou seja não podem ficar vazios
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS clientes (
            id INTEGER PRIMARY KEY AUTOINCREMENT,  # Chave primária autoincrementada para identificação única do cliente
            nome TEXT NOT NULL,  # Nome do cliente (campo obrigatório)
            idade INTEGER NOT NULL,  # Idade do cliente (campo obrigatório)
            peso INTEGER NOT NULL,  # Peso do cliente (campo obrigatório)
            altura INTEGER NOT NULL,  # Altura do cliente (campo obrigatório)
            imc INTENGER NOT NULL  # Índice de Massa Corporal (IMC) do cliente (campo obrigatório) [OBS: há um erro na escrita de 'INTEGER']
        )
    ''')
    
    # Confirma a criação da tabela no banco de dados
    conexao.commit()  
    # Fecha a conexão com o banco de dados
    conexao.close()

# Estabelece uma conexão separada com o banco de dados antes de chamar a função
conexao = sqlite3.connect('../../../../gym.db')

# Chama a função para criar a tabela 'clientes' no banco de dados
create_clientes_table()

# Fecha a conexão com o banco de dados
conexao.close()  
