# Importação da biblioteca SQLite3 para manipulação do banco de dados
import sqlite3

# Função para inserir um novo cliente na tabela 'clientes'
def inserir_cliente(conexao):
    # Captura de dados do usuário através do input
    nome = input("Escreva o seu nome: ")  # Solicita o nome do cliente
    idade = int(input("Escreva a sua idade: "))  # Solicita a idade e converte para inteiro
    altura = float(input("Escreva a sua altura (em metros): "))  # Solicita a altura e converte para float
    peso = float(input("Escreva o seu peso (em kg): "))  # Solicita o peso e converte para float
    
    # Cálculo do Índice de Massa Corporal (IMC)
    imc = round(peso / (altura ** 2), 2)  # Fórmula do IMC arredondado para 2 casas decimais

    # Criação do cursor para interagir com o banco de dados
    cursor = conexao.cursor()

    # Comando SQL para inserir os dados do cliente na tabela 'clientes'
    cursor.execute(
        'INSERT INTO clientes (nome, idade, peso, altura, imc) VALUES (?, ?, ?, ?, ?)', 
        (nome, idade, peso, altura, imc)  # Passagem dos valores capturados como parâmetros
    )

    # Confirma a inserção dos dados no banco de dados
    conexao.commit()

    # Mensagem de sucesso após a inserção do cliente
    print("Cliente registrado com sucesso!")
