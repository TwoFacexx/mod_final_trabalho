# Importação da biblioteca SQLite3 para manipulação do banco de dados
import sqlite3

# Função para selecionar e exibir todos os dados da tabela 'clientes'
def select_dados(conexao):
    # Criação do cursor para executar comandos SQL
    cursor = conexao.cursor()
    
    # Executa um comando SQL para selecionar todos os registros da tabela 'clientes'
    cursor.execute('SELECT * FROM clientes')
    
    # Obtém todos os resultados da consulta
    resultados = cursor.fetchall()
 
    # Percorre a lista de clientes retornados do banco de dados e exibe cada um deles
    for cliente in resultados:
        print(cliente)
