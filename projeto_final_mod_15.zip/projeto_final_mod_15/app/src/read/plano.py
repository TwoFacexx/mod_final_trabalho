# Importação da biblioteca SQLite3 para manipulação do banco de dados
import sqlite3

# Função para determinar o plano de treino com base no IMC do cliente
def plano_de_treino(imc):
    # Define o tipo de treino conforme a faixa do IMC
    if imc < 18.5:
        return "Treino para ganho de massa"  # Pessoas abaixo do peso precisam ganhar massa muscular
    elif 18.5 <= imc <= 24.9:
        return "Treino para definição do corpo"  # IMC normal, foco na definição
    elif 25 <= imc <= 29.9:
        return "Treino para perda de peso"  # Sobrepeso, objetivo é emagrecimento
    elif 30 <= imc <= 34.9:
        return "Treino para perda de peso"  # Obesidade grau 1, perda de peso recomendada
    elif 35 <= imc <= 39.9:
        return "Treino para perda de peso"  # Obesidade grau 2, foco em emagrecimento
    else:
        return "Treino para perda de peso"  # Obesidade grau 3, objetivo prioritário é redução de peso
    
# Função para exibir o plano de treino recomendado para cada cliente no banco de dados
def plan(conexao):
    # Criação do cursor para executar comandos SQL
    cursor = conexao.cursor()
    
    # Executa um comando SQL para selecionar todos os dados da tabela 'clientes'
    cursor.execute('SELECT * FROM clientes')
    
    # Obtém todos os resultados da consulta
    resultados = cursor.fetchall()
 
    # Percorre a lista de clientes retornados do banco de dados
    for cliente in resultados:
        # Extrai os dados de cada cliente baseado na posição das colunas na tabela
        nome = cliente[1]  # Nome do cliente
        idade = cliente[2]  # Idade do cliente
        peso = cliente[3]  # Peso do cliente em kg
        altura = cliente[4]  # Altura do cliente em metros
        imc = cliente[5]  # Índice de Massa Corporal (IMC) do cliente

        # Determina o plano de treino recomendado com base no IMC
        plano = plano_de_treino(imc)
        
        # Exibe as informações do cliente junto com o plano de treino recomendado
        print(f'Cliente: {nome}, Idade: {idade}, Peso: {peso}kg, Altura: {altura}m, IMC: {imc}, Tipo de plano de treino recomendado: {plano}')

# Executa a consulta e exibição dos dados se o script for executado diretamente
if __name__ == "__main__":
    # Estabelece uma conexão com o banco de dados 'gym.db'
    conexao = sqlite3.connect('../gym.db')
    
    # Chama a função para selecionar os dados dos clientes e exibir os planos de treino recomendados
    plan(conexao)
    
    # Fecha a conexão com o banco de dados após a execução
    conexao.close()
