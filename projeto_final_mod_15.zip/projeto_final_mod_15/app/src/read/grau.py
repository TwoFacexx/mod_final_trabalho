# Importação da biblioteca SQLite3 para manipulação do banco de dados
import sqlite3

# Função para calcular o grau de obesidade com base no IMC
def calcular_grau(imc):
    # Verifica e retorna a classificação do IMC de acordo com os valores estabelecidos
    if imc < 18.5:
        return "Abaixo do peso"
    elif 18.5 <= imc <= 24.9:
        return "Peso normal"
    elif 25 <= imc <= 29.9:
        return "Sobrepeso"
    elif 30 <= imc <= 34.9:
        return "Obesidade grau 1"
    elif 35 <= imc <= 39.9:
        return "Obesidade grau 2"
    else:
        return "Obesidade grau 3"

# Função para selecionar os dados dos clientes no banco de dados
def sel_dados(conexao):
    # Criação do cursor para executar comandos SQL
    cursor = conexao.cursor()
    
    # Executa um comando SQL para selecionar todos os dados da tabela 'clientes'
    cursor.execute('SELECT * FROM clientes')
    
    # Obtém todos os resultados da consulta
    resultados = cursor.fetchall()
 
    # Percorre a lista de clientes retornados do banco de dados
    for cliente in resultados:
        # Extrai os dados de cada cliente baseado na posição das colunas na tabela
        nome = cliente[1]  # Nome do cliente
        idade = cliente[2]  # Idade do cliente
        peso = cliente[3]  # Peso do cliente em kg
        altura = cliente[4]  # Altura do cliente em metros
        imc = cliente[5]  # Índice de Massa Corporal (IMC) do cliente

        # Calcula o grau de obesidade baseado no IMC do cliente
        grau_imc = calcular_grau(imc)
        
        # Exibe as informações do cliente formatadas no terminal
        print(f'Cliente: {nome}, Idade: {idade}, Peso: {peso}kg, Altura: {altura}m, IMC: {imc}, Grau do IMC: {grau_imc}')

# Executa a consulta e exibição dos dados se o script for executado diretamente
if __name__ == "__main__":
    # Estabelece uma conexão com o banco de dados 'gym.db'
    conexao = sqlite3.connect('../gym.db')
    
    # Chama a função para selecionar e exibir os dados dos clientes
    sel_dados(conexao)
    
    # Fecha a conexão com o banco de dados após a execução
    conexao.close()
