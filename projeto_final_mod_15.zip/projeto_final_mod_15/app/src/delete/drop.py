# Importação da biblioteca SQLite3 para manipulação do banco de dados
import sqlite3

# Função para apagar uma tabela do banco de dados
def apagar_tabela(conexao):
    # Criação de um cursor para executar comandos SQL
    cursor = conexao.cursor()

    # Solicita ao usuário o nome da tabela que deseja apagar
    tabela = input("Escreva o nome da tabela que deseja apagar: ")

    # Executa o comando SQL para apagar a tabela informada
    cursor.execute(f"DROP TABLE {tabela};")

    # Confirma a execução do comando no banco de dados
    conexao.commit()
