# Importação da biblioteca SQLite3 para manipulação do banco de dados
import sqlite3

# Função para excluir um cliente do banco de dados
def delete_cliente(conexao):
    # Criação do cursor para executar comandos SQL
    cursor = conexao.cursor()
    
    # Solicita o ID do cliente a ser deletado
    id = input("Escreva o ID do cliente que quer deletar: ")

    # Executa o comando SQL para deletar o cliente com o ID informado
    cursor.execute("DELETE FROM clientes WHERE id = ?", (id,))  # <-- (id,) é uma tupla com um único elemento
    
    # Confirma a remoção do cliente do banco de dados
    conexao.commit()
    
    # Fecha a conexão com o banco de dados
    conexao.close()
